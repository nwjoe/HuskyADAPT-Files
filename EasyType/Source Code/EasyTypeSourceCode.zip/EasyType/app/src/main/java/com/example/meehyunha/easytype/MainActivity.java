package com.example.meehyunha.easytype;

import android.app.Activity;

/**
 * Created by meehyunha on 2/14/18.
 */

public class MainActivity extends Activity {
}
